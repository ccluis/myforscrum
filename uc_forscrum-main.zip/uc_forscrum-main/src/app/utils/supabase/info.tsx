/* Projeto Supabase do MyforScrum e chave pública (anon), feita para ser usada na aplicação. */

export const projectId = "malixbxxfqzzszvjyrla"
export const publicAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1hbGl4Ynh4ZnF6enN6dmp5cmxhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzkwOTIwNjIsImV4cCI6MjA5NDY2ODA2Mn0.zF2DcL_WfSz76s9HG_9G-mzHWNW-zCnekdUc1oRR0Es"
